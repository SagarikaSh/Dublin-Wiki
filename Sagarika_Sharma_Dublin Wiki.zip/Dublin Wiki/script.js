
'use strict'
const testimonials = document.querySelectorAll('.testimonial');
let index = 0;

function showTestimonial() {
    console.log('Changing testimonial...');
    testimonials.forEach(testimonial => testimonial.classList.remove('active'));
    testimonials[index].classList.add('active');
    index = (index + 1) % testimonials.length;
}

showTestimonial(); // Show the first testimonial
setInterval(showTestimonial, 4000); // Change testimonial every 4 seconds
